class Finance < ApplicationRecord
    belongs_to :farm
end
