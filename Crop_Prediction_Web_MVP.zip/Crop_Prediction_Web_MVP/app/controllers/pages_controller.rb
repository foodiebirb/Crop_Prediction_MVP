class PagesController < ApplicationController
    def show
      render template: "pages/result"
    end
  end